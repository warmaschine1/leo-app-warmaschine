package de.slgdev.leoapp.view;

/**
 * ActivityStatus
 * <p>
 * Gibt den Status einer Activity an.
 */

public enum ActivityStatus {
    ACTIVE, PAUSED, DESTROYED
}
