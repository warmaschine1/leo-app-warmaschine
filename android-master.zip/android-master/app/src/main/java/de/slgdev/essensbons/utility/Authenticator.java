package de.slgdev.essensbons.utility;

public enum Authenticator {
    NO_CONNECTION, NOT_VALID, VALID
}
