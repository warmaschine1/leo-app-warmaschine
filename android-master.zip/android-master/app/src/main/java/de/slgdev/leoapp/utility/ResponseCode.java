package de.slgdev.leoapp.utility;

public enum ResponseCode {
    NO_CONNECTION, AUTH_FAILED, SERVER_FAILED, SUCCESS, NOT_SENT
}
