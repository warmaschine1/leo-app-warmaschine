package de.slgdev.leoapp.utility;

public enum NetworkPerformance {
    EXCELLENT, MEDIOCRE, INSUFFICIENT, NOT_AVAILABLE
}
