package de.slgdev.startseite;

interface RecyclerViewItemListener {
    void onItemDismiss(int position);
}
