package de.slgdev.messenger.utility;

public class Assoziation {
    public final int cid;
    public final int uid;

    public Assoziation(int cid, int uid) {
        this.cid = cid;
        this.uid = uid;
    }
}