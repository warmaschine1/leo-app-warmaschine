package de.slgdev.stimmungsbarometer.utility;

public class Vote {
    public final int voteid;
    public final int userid;

    public Vote(int voteid, int userid) {
        this.voteid = voteid;
        this.userid = userid;
    }
}
