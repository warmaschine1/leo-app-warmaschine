package de.slgdev.leoapp.activity.fragment;

import android.support.v4.app.Fragment;

public abstract class AbstractOrderedFragment extends Fragment {
    public abstract int getPosition();
}
