package de.slgdev.it_problem.utility;

public class Utils {
}
